# E-commerce-App
E-commerce App, open source mobile app for Shopping . Built with Kotlin. and firebase and mvvm-architecture
ScreenShot of Home Activity
![Screenshot_1592904587](https://user-images.githubusercontent.com/60369343/85407472-1981c900-b518-11ea-947a-683877c2247e.png)
![Screenshot_1592904591](https://user-images.githubusercontent.com/60369343/85407480-1c7cb980-b518-11ea-93e0-6db00172263e.png)
![Screenshot_1592904583](https://user-images.githubusercontent.com/60369343/85407929-b5abd000-b518-11ea-8d1e-8596bc6ddc8a.png)
ScreenShot of Search Activity
![Screenshot_1592904597](https://user-images.githubusercontent.com/60369343/85407774-7da48d00-b518-11ea-9b89-429256625506.png)
ScreenShot of favorite Activity
![Screenshot_1592904602](https://user-images.githubusercontent.com/60369343/85408054-e12eba80-b518-11ea-92dd-b7f3185e7e08.png)

ScreenShot of add to car and buy item Activity
![Screenshot_1592911609](https://user-images.githubusercontent.com/60369343/85408178-09b6b480-b519-11ea-8b85-3e726529448b.png)
![Screenshot_1592917608](https://user-images.githubusercontent.com/60369343/85408188-0c190e80-b519-11ea-96c4-acdb7576822a.png)
